package com.example.sejjoh.gslsadmin;

public class HospitalAdapter {
}
