package com.example.sejjoh.gsls;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.sejjoh.gsls.models.MessageModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MessageActivity extends AppCompatActivity implements View.OnLongClickListener{
    boolean is_in_message_mode = false;
    ImageView messageback;
    ImageView messagedelete;
    ImageView messageimage;
    TextView messagename;
    FirebaseUser user;
    DatabaseReference messagereference;
    EditText messagetext;
    ImageView messagesent;
    RecyclerView messagerecyclerview;
    Toolbar toolbarsms;
    MessageAdapter messageAdapter;
    List<MessageModel> messageModels;


    ValueEventListener eventListener;


    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        messageback = findViewById(R.id.messageBack);
        messagedelete = findViewById(R.id.messageDelete);
        messageback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        messageimage = findViewById(R.id.messageImage);
        messagename = findViewById(R.id.messageName);
        user = FirebaseAuth.getInstance().getCurrentUser();

        toolbarsms = findViewById(R.id.toolbarsms);


        intent = getIntent();
        final String userid = intent.getStringExtra("Userid");
        messagereference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
        messagereference.keepSynced(true);
        messagereference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final saveData addData = dataSnapshot.getValue(saveData.class);

                assert addData != null;
                messagename.setText(addData.getUpcurrentuser());

                Picasso.with(getApplicationContext())
                        .load(addData.getImageURL())
                        .networkPolicy(NetworkPolicy.OFFLINE)
                        .into(messageimage, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {
                                Picasso.with(getApplicationContext()).load(addData.getImageURL())
                                        .into(messageimage);
                            }
                        });

                readMessage(user.getUid(), userid, addData.getImageURL());

                toolbarsms.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(MessageActivity.this, SenderDetails.class);
                        intent.putExtra("Upuserid", addData.getUpuserid());
                        startActivity(intent);
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        messagetext = findViewById(R.id.mesageText);
        messagesent = findViewById(R.id.messagesend);
        messagerecyclerview = findViewById(R.id.messageRecyclerview);
        messagerecyclerview.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setStackFromEnd(true);
        messagerecyclerview.setLayoutManager(layoutManager);
        messagesent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messagetext.getText().toString();

                if (!message.equals("")){
                    sendMessage(user.getUid(), userid, message);
                }else {
                    Toast.makeText(MessageActivity.this, "You can't send empty message", Toast.LENGTH_SHORT).show();
                }
                messagetext.setText("");
            }
        });
        seenMessage(userid);

    }

    public  void seenMessage(String userid){
        messagereference = FirebaseDatabase.getInstance().getReference("Chats");
        eventListener = messagereference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    MessageModel model = dataSnapshot1.getValue(MessageModel.class);
                    if (model.getReceiver().equals(user.getUid()) && model.getSender().equals(user.getUid())){
                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("seen", true);
                        dataSnapshot1.getRef().updateChildren(hashMap);

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void sendMessage(String sender, String receiver, String message){

        intent = getIntent();
        final String userid = intent.getStringExtra("Userid");

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender", sender);
        hashMap.put("receiver", receiver);
        hashMap.put("message", message);
        hashMap.put("seen", false);

        reference.child("Chats").push().setValue(hashMap);

        final DatabaseReference chatreference = FirebaseDatabase.getInstance().getReference("Chatlist")
                .child(user.getUid())
                .child(userid);

        chatreference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()){
                    chatreference.child("id").setValue(userid);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void readMessage(final String myid, final String userid, final String imgUrl){
        messageModels = new ArrayList<>();
        messagereference = FirebaseDatabase.getInstance().getReference("Chats");
        messagereference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                messageModels.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    MessageModel model = snapshot.getValue(MessageModel.class);
                    if (model.getReceiver().equals(myid) && model.getSender().equals(userid) ||
                            model.getReceiver().equals(userid) && model.getSender().equals(myid)){
                        messageModels.add(model);

                    }

                    messageAdapter = new MessageAdapter(MessageActivity.this, messageModels, imgUrl);
                    messagerecyclerview.setAdapter(messageAdapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void status(String status){
        messagereference = FirebaseDatabase.getInstance().getReference("Users").child(user.getUid());

        String userId = user.getUid();
        HashMap<String, Object> hashMap = new HashMap<>();

        hashMap.put("status", status);
        hashMap.put("upuserid", userId);

        messagereference.updateChildren(hashMap);

    }

    @Override
    protected void onResume() {
        super.onResume();
        status("online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        messagereference.removeEventListener(eventListener);
    }

    public void onBackPressed() {


        super.onBackPressed();
    }

    @Override
    public boolean onLongClick(View v) {
        messagedelete.setVisibility(View.VISIBLE);
        return true;
    }
}
