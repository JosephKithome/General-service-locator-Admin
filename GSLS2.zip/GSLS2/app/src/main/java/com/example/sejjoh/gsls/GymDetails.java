package com.example.sejjoh.gsls;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.sejjoh.gsls.models.GymModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GymDetails extends AppCompatActivity {

    FirebaseDatabase mdatabase;
    private ImageView mImageView;
    private TextView MAiportname;
    DatabaseReference Mreference;
    private TextView Mdesc;
    private TextView mlocation;
    private TextView mChat;
    String gym;

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gym_details);
        mdatabase= FirebaseDatabase.getInstance();
        Mreference=mdatabase.getReference().child("Gym");
        mImageView=(ImageView)findViewById(R.id.service_image);
        Mdesc=(TextView)findViewById(R.id.post_description);
        mlocation=(TextView)findViewById(R.id.location);
        mChat=(TextView)findViewById(R.id.chat);
        toolbar=findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);

        toolbar.setTitle("service");
        if(getIntent() !=null)
            gym=getIntent().getStringExtra("GymId");
        if(!gym.isEmpty())
        {
            getDetailHotel(gym);
        }
    }

    private void getDetailHotel(String gym) {

        Mreference.child(gym).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                GymModel GymModel=dataSnapshot.getValue(GymModel.class);
                Mdesc.setText(GymModel.getGymdescription());
               //toolbar.setTitle(GymModel.getGymName());

                Glide.with(getBaseContext()).load(GymModel.getGymimage()).into(mImageView);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent locationIntent=new Intent(GymDetails.this, GeoLocation.class);
                startActivity(locationIntent);
            }
        });
        mChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent chatIntent=new Intent(GymDetails.this, MessageActivity.class);
                startActivity(chatIntent);
            }
        });

    }

}