package com.example.sejjoh.gsls;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class WelcomeScreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);


                ImageView imageView=(ImageView)findViewById(R.id.rotate);
                TextView textView=(TextView)findViewById(R.id.gsls);
                TextView textView1=(TextView)findViewById(R.id.start);
                ImageView imageView1=(ImageView)findViewById(R.id.rotating);

                Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                imageView.startAnimation(animation);
                Animation animation1= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.downanime);
                textView.startAnimation(animation1);
                Animation animation2=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                imageView1.startAnimation(animation2);

                textView1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent welcome= new Intent(WelcomeScreen.this,MainActivity.class);
                        startActivity(welcome);
                    }
                });
            }
        }
