package com.example.sejjoh.gsls;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sejjoh.gsls.models.MessageModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    public static final int MSG_TYPE_LEFT = 0;
    public static final int MSG_TYPE_RIGHT = 1;

    private Context mContext;
    private List<MessageModel> mMessage;
    String imgUrl;
    MessageActivity messageactivity;

    FirebaseUser fuser;

    public MessageAdapter(Context mContext, List<MessageModel> mlist, String imgUrl) {
        this.mContext = mContext;
        this.mMessage = mlist;
        this.imgUrl = imgUrl;
        messageactivity = (MessageActivity) mContext;

    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        if (i == MSG_TYPE_RIGHT) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right, viewGroup, false);
            return new MessageViewHolder(view);
        }else {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left, viewGroup, false);
            return new MessageViewHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder messageViewHolder, int i) {
        final MessageModel model = mMessage.get(i);
        messageViewHolder.chatitemtext.setText(model.getMessage());

        if (!messageactivity.is_in_message_mode){

        }
//        Glide.with(mContext).load(model.getImageURL()).into(messageViewHolder.chatitemimage);

//            if (model.isSeen()){
//                messageViewHolder.textseen.setImageResource(R.drawable.ic_done_black_24dp);
//            }
//            else {
//                messageViewHolder.textseen.setImageResource(R.drawable.ic_done_black_24dp);
//            }


    }

    @Override
    public int getItemCount() {
        return mMessage.size();
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener{
        ImageView chatitemimage;
        TextView chatitemtext;
        ImageView textseen;
        MessageActivity messageActivity;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);

            chatitemtext = itemView.findViewById(R.id.chatItemText);
            chatitemimage = itemView.findViewById(R.id.chatItemImage);
            textseen = itemView.findViewById(R.id.textSeen);
            this.messageActivity = messageactivity;
            chatitemtext.setOnLongClickListener(messageActivity);

        }

        @Override
        public boolean onLongClick(View v) {

            return false;
        }
    }

    @Override
    public int getItemViewType(int position) {
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        if (mMessage.get(position).getSender().equals(fuser.getUid())){
            return MSG_TYPE_RIGHT;
        }else {
            return MSG_TYPE_LEFT;
        }
    }
}

