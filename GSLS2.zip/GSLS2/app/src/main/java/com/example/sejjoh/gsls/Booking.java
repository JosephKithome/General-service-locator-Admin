package com.example.sejjoh.gsls;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.widget.LinearLayout;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Booking extends AppCompatActivity {
    WebView booksite;
    FirebaseDatabase db;
    DatabaseReference databaseReference;

    String HotelId="";

    LinearLayout webvieLayout;
    LinearLayout loadingProgress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
    }}