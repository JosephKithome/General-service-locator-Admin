package com.example.sejjoh.gsls;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.sejjoh.gsls.models.AirportModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Airportdetails extends AppCompatActivity {

    String  Airport;

    FirebaseDatabase mdatabase;
    private ImageView mImageView;
    private TextView MAiportname;
    DatabaseReference Mreference;
    private TextView Mdesc;
    private TextView mlocation;
    private TextView mChat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airportdetails);
        mdatabase=FirebaseDatabase.getInstance();
        Mreference=mdatabase.getReference().child("Aiport");
        mImageView=(ImageView)findViewById(R.id.service_image);
        MAiportname=(TextView)findViewById(R.id.post_description);
        Mdesc=(TextView)findViewById(R.id.post_description);
        mlocation=(TextView)findViewById(R.id.location);
        mChat=(TextView)findViewById(R.id.chat);
        if(getIntent() !=null)
            Airport=getIntent().getStringExtra("airportId");
        if(!Airport.isEmpty())
        {
            getDetailHotel(Airport);
        }
    }

    private void getDetailHotel(String airport) {

        Mreference.child(Airport).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                AirportModel airportModel=dataSnapshot.getValue(AirportModel.class);

                MAiportname.setText(airportModel.getAiport());
                Mdesc.setText(airportModel.getDescription());

                Glide.with(getBaseContext()).load(airportModel.getImage()).into(mImageView);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent locationIntent=new Intent(Airportdetails.this, GeoLocation.class);
                startActivity(locationIntent);
            }
        });
        mChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent chatIntent=new Intent(Airportdetails.this, MessageActivity.class);
                startActivity(chatIntent);
            }
        });

    }

}