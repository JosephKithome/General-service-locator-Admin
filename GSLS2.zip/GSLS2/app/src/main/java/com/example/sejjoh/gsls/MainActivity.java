package com.example.sejjoh.gsls;

import android.app.Dialog;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tablayout;
    Toolbar toolbar;

    private FirebaseAuth mAuth;
    private DatabaseReference mdatabaseUser;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private static final String TAG = "MainActivity";
    private static final int ERROR_DIALOG_REQUEST = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        tablayout = (TabLayout) findViewById(R.id.tablayout);
        //create and set ViewPager adapter
        setupViewPager(viewPager);
        tablayout.setupWithViewPager(viewPager);

        //change selected tab when viewpager changed page
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tablayout));

        //change viewpager page when tab selected
        tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                viewPager.setCurrentItem(tab.getPosition());

                switch (tab.getPosition()) {
                    case 0:

                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    private void setupViewPager(ViewPager viewPager) {

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new FragmentGym(
                ContextCompat.getColor(this, R.color.white)), "Gym");
        adapter.addFrag(new FragmentMechanics(
                ContextCompat.getColor(this, R.color.white)), "Mechanics");
        adapter.addFrag(new FragmentLaundry(
                ContextCompat.getColor(this, R.color.white)), "Laundry");
        adapter.addFrag(new FragmentPicnics(
                ContextCompat.getColor(this, R.color.white)), "Picnics");
        adapter.addFrag(new FragmentAirport(
                ContextCompat.getColor(this, R.color.white)), "Airport");
        adapter.addFrag(new FragmentBank(
                ContextCompat.getColor(this, R.color.white)), "Bank");
        adapter.addFrag(new FragmentVeterinaryServices(
                ContextCompat.getColor(this, R.color.white)), "Veterinary");
        adapter.addFrag(new FragmentHotel(
                ContextCompat.getColor(this, R.color.white)), "Hotels");
        viewPager.setAdapter(adapter);
        if (isServicesOK()){
            init();
        }
    }
    private void init(){

    }
    public boolean isServicesOK(){
        Log.d(TAG,"isServicesOK:checking google services version");
        int available= GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this);
        if (available== ConnectionResult.SUCCESS){
            //everything is okay and the user can make map requests
            Log.d(TAG,"isServicesOK:Google play services is working");
            return true;

        }else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)){
            //an error occurred but we can fix it
            Log.d(TAG,"isServicesOK:an error occurred but we can fix it");
            Dialog dialog=GoogleApiAvailability.getInstance().getErrorDialog(MainActivity.this,available,ERROR_DIALOG_REQUEST);
            dialog.show();

        }else {
            Toast.makeText(this, "You cant make map requests", Toast.LENGTH_SHORT).show();
        }
        return false;
    }


}
